export interface Bebida{
    id: number;
    nombre: string;
    descripcion: string;
    imagenUrl: string;
    precio: number;
    stock: number;
}
